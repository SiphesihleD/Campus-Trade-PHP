<?php
/* ================================================================
   CAMPUS TRADE — api/payfast.php
   Handles PayFast Sandbox payment initiation, ITN (callback),
   return, cancel, and payment status polling.
   ================================================================ */

// Allow Firebase Hosting frontend to call this PHP backend
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit(); }

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/payfast_config.php';
startSession();

$action = $_GET['action'] ?? '';

match ($action) {
    'initiate' => initiatePayment(),
    'itn'      => handleITN(),          // PayFast server-to-server notify
    'status'   => getPaymentStatus(),
    default    => error("Unknown action: $action", 404)
};

/* ----------------------------------------------------------------
   1. INITIATE — build PayFast form fields and return to frontend
   ---------------------------------------------------------------- */
function initiatePayment(): void {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') error('POST required', 405);
    $user = requireLogin();
    $db   = getDB();
    $body = getBody();

    $listingId = (int)  ($body['listingId']       ?? 0);
    $pm        = sanitize($body['paymentMethod']   ?? '');
    $meetup    = sanitize($body['meetupLocation']  ?? '');
    $note      = sanitize($body['note']            ?? '');

    if (!$listingId)           error('Listing ID required.');
    if ($pm !== 'payfast')     error('Payment method must be payfast.');

    // Load listing
    $listing = $db->fetchOne(
        'SELECT l.*, u.email AS seller_email, u.display_name AS seller_name
         FROM listings l
         JOIN users u ON l.seller_id = u.id
         WHERE l.id = ? AND l.status = "active"',
        'i', $listingId
    );
    if (!$listing)                          error('Listing not found or already sold.');
    if ($listing['seller_id'] === $user['id']) error('You cannot buy your own listing.');

    $subtotal   = (float) $listing['price'];
    $fee        = round($subtotal * COMMISSION, 2);
    $sellerGets = round($subtotal * (1 - COMMISSION), 2);
    $total      = round($subtotal + $fee, 2);   // buyer pays subtotal + platform fee

    // Create a PENDING order in DB first (we need the order ID as merchant_reference)
    $db->beginTransaction();
    try {
        $orderId = $db->insert(
            'INSERT INTO orders
               (buyer_id, seller_id, listing_id, subtotal, platform_fee, seller_gets,
                payment_method, meetup_location, note, status)
             VALUES (?, ?, ?, ?, ?, ?, "payfast", ?, ?, "pending")',
            'iiidddss',
            $user['id'], $listing['seller_id'], $listingId,
            $subtotal, $fee, $sellerGets,
            $meetup, $note
        );
        $db->commit();
    } catch (Exception $e) {
        $db->rollback();
        error('Could not create order: ' . $e->getMessage());
    }

    // Build PayFast payload
    $merchantRef = 'CT-' . $orderId;
    $data = [
        // Merchant details
        'merchant_id'   => PF_MERCHANT_ID,
        'merchant_key'  => PF_MERCHANT_KEY,
        'return_url'    => PF_RETURN_URL  . '?order_id=' . $orderId,
        'cancel_url'    => PF_CANCEL_URL  . '?order_id=' . $orderId,
        'notify_url'    => PF_NOTIFY_URL,

        // Buyer info
        'name_first'    => $user['display_name'] ?? 'Campus',
        'name_last'     => 'Student',
        'email_address' => $user['email'],

        // Transaction
        'merchant_payment_id' => $merchantRef,
        'amount'              => number_format($total, 2, '.', ''),
        'item_name'           => substr($listing['title'], 0, 100),
        'item_description'    => 'Campus Trade order #' . $orderId,

        // Custom data — we'll verify this in ITN
        'custom_int1'   => $orderId,
        'custom_str1'   => $user['id'],
    ];

    // Generate signature
    $data['signature'] = generateSignature($data);

    success([
        'orderId'       => $orderId,
        'payfast_url'   => PF_PAYMENT_URL,
        'payfast_data'  => $data,
    ], 'Payment initiated.');
}

/* ----------------------------------------------------------------
   2. ITN — Instant Transaction Notification from PayFast
      Called server-to-server; must be publicly reachable.
   ---------------------------------------------------------------- */
function handleITN(): void {
    // ITN arrives as POST from PayFast; no session / CORS needed
    $pfData = $_POST;

    // 1 — Validate signature
    $receivedSig = $pfData['signature'] ?? '';
    $calcSig     = generateSignature($pfData, true /* skip signature field */);
    if ($receivedSig !== $calcSig) {
        http_response_code(400);
        exit('Invalid signature');
    }

    // 2 — Validate PayFast IP
    $validIPs = [
        '197.97.145.144','197.97.145.145','197.97.145.146','197.97.145.147',
        '41.74.179.193','41.74.179.194','41.74.179.195','41.74.179.196',
        // Sandbox IPs
        '197.97.145.144','196.11.229.253',
    ];
    $remoteIP = $_SERVER['REMOTE_ADDR'] ?? '';
    // In sandbox mode, relax IP check (sandbox uses different ranges)
    if (!PF_SANDBOX && !in_array($remoteIP, $validIPs)) {
        http_response_code(400);
        exit('Invalid IP');
    }

    // 3 — Extract data
    $orderId       = (int)   ($pfData['custom_int1']          ?? 0);
    $paymentStatus = strtolower($pfData['payment_status']     ?? '');
    $pfPaymentId   = sanitize($pfData['pf_payment_id']        ?? '');
    $amountGross   = (float) ($pfData['amount_gross']         ?? 0);

    if (!$orderId) { http_response_code(400); exit('Missing order'); }

    $db = getDB();
    $order = $db->fetchOne('SELECT * FROM orders WHERE id = ?', 'i', $orderId);
    if (!$order) { http_response_code(400); exit('Order not found'); }

    // 4 — Verify amount (buyer paid subtotal + fee)
    $expectedAmount = round((float)$order['subtotal'] + (float)$order['platform_fee'], 2);
    if (abs($amountGross - $expectedAmount) > 0.01) {
        http_response_code(400);
        exit('Amount mismatch');
    }

    // 5 — Update order based on PayFast payment_status
    $newStatus = match($paymentStatus) {
        'complete'  => 'confirmed',
        'failed'    => 'cancelled',
        'cancelled' => 'cancelled',
        default     => 'pending',
    };

    $db->beginTransaction();
    try {
        $db->execute(
            'UPDATE orders SET status = ?, pf_payment_id = ? WHERE id = ?',
            'ssi', $newStatus, $pfPaymentId, $orderId
        );

        if ($newStatus === 'confirmed') {
            // Mark listing sold
            $db->execute(
                "UPDATE listings SET status = 'sold', sold_at = NOW() WHERE id = ?",
                'i', $order['listing_id']
            );
            // Notify seller
            $listing = $db->fetchOne('SELECT title FROM listings WHERE id = ?', 'i', $order['listing_id']);
            $db->execute(
                'INSERT INTO notifications (user_id, type, title, message, link_url)
                 VALUES (?, "sale", ?, ?, "/pages/dashboard.html")',
                'isss',
                $order['seller_id'],
                '🎉 Payment Received!',
                '"' . ($listing['title'] ?? 'Item') . '" — payment confirmed via PayFast.'
            );
        }

        $db->commit();
    } catch (Exception $e) {
        $db->rollback();
        http_response_code(500);
        exit('DB error: ' . $e->getMessage());
    }

    http_response_code(200);
    exit('OK');
}

/* ----------------------------------------------------------------
   3. STATUS — poll order payment status (for return/cancel pages)
   ---------------------------------------------------------------- */
function getPaymentStatus(): void {
    $user    = requireLogin();
    $orderId = (int)($_GET['order_id'] ?? 0);
    if (!$orderId) error('order_id required.');

    $db    = getDB();
    $order = $db->fetchOne(
        'SELECT id, status, subtotal, platform_fee, seller_gets, payment_method,
                pf_payment_id, created_at
         FROM orders WHERE id = ? AND buyer_id = ?',
        'ii', $orderId, $user['id']
    );
    if (!$order) error('Order not found.', 404);
    success($order);
}

/* ----------------------------------------------------------------
   HELPERS
   ---------------------------------------------------------------- */

/**
 * Build and MD5-hash the PayFast signature string.
 * @param array  $data        Key-value pairs
 * @param bool   $skipSig     True when verifying received ITN (omit 'signature' field)
 */
function generateSignature(array $data, bool $skipSig = false): string {
    // Remove signature key if present
    if ($skipSig) unset($data['signature']);

    // Remove empty values, keep order
    $parts = [];
    foreach ($data as $key => $value) {
        if ($key === 'signature') continue;
        if ($value === '' || $value === null) continue;
        $parts[] = $key . '=' . urlencode(trim((string)$value));
    }

    $str = implode('&', $parts);

    // Append passphrase if set
    if (!empty(PF_PASSPHRASE)) {
        $str .= '&passphrase=' . urlencode(trim(PF_PASSPHRASE));
    }

    return md5($str);
}
